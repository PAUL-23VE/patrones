﻿using Interface_Segregation_Principle;

namespace Interface_segregation__GOOD_
{
    internal class Robot : IWorkable
    {
        void IWorkable.Work()
        {
            Console.WriteLine("Un robot trabaja...");
        }
    }
    
    
}
