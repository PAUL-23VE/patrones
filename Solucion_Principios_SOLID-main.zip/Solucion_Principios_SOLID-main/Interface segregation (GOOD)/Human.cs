﻿using Interface_Segregation_Principle;

namespace Interface_segregation__GOOD_
{
    internal class Human : IWorkable, IEtable
    {
        void IWorkable.Work()
        {
            Console.WriteLine("Un humano trabaja...");
        }

        void IEtable.Eat()
        {
            Console.WriteLine("Un humano come...");
        }
    }
}
