﻿namespace Interface_Segregation_Principle
{
    internal interface IWorkable
    {
        void Work();
    }
}
