﻿namespace Interface_Segregation_Principle
{
    internal interface IEtable
    {
        void Eat();
    }
}
