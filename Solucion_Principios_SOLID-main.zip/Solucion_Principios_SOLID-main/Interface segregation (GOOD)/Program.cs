﻿using Interface_Segregation_Principle;

namespace Interface_segregation__GOOD_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //IWorkable robot = new Robot();
            //IWorkable human = new Human();

            //IEtable humanEtar = new Human();

            //humanEtar.Eat();
            Robot robot = new Robot();
            Human human = new Human();
            robot.Work();
            human.
            human.Eat();
           
        }
        

    }
}
