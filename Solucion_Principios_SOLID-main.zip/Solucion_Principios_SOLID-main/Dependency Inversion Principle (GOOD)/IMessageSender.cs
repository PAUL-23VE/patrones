﻿using System.Security.Cryptography;

namespace Dependency_Inversion_Principle__GOOD_
{
    internal interface IMessageSender
    {
        void SendMessage(string message, string receiver);
    }
}
