﻿namespace Dependency_Inversion_Principle__GOOD_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            IMessageSender emailSender = new EmailSender();

            NotificationService notificationService = new NotificationService(emailSender);

            notificationService.SendNotification("Hola","test@gmail.com");

            IMessageSender smsSender = new SMSSender();
            smsSender.SendMessage("Hola", "1234567890");

            IMessageSender whatsappSender = new WhatsAppSender();
            whatsappSender.SendMessage("Hola", "Contacto X");
        }
    }
}
