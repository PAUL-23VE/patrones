﻿using System.Security.Cryptography;

namespace Dependency_Inversion_Principle__GOOD_
{
    public class EmailSender : IMessageSender
    {
        void IMessageSender.SendMessage(string message, string receiver)
        {
            Console.WriteLine($"Email enviado para {receiver}: {message}");
        }
    }
}
