﻿namespace Dependency_Inversion_Principle__GOOD_
{
    public class WhatsAppSender : IMessageSender
    {
        void IMessageSender.SendMessage(string message, string receiver)
        {
            Console.WriteLine($"WhatsApp enviado para {receiver}: {message}");
        }
    }
}
