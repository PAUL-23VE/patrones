﻿namespace Dependency_Inversion_Principle__GOOD_
{
    public class SMSSender : IMessageSender
    {
        void IMessageSender.SendMessage(string message, string receiver)
        {
            Console.WriteLine($"SMS enviado para {receiver}: {message}");
        }
    }
}
