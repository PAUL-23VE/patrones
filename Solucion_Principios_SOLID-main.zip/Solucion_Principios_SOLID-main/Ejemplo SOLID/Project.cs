﻿namespace Ejemplo_SOLID
{
    /// <summary>
    /// Clase de alto nivel
    /// La clase ahora depende de IDeveloper
    /// </summary>
    public class Project
    {
        private readonly List<IDeveloper> _developers;

        public Project(List<IDeveloper> developers)
        {
            _developers = developers;   
        }

        public void Build()
        {
            foreach (var developer in _developers)
            {
                developer.Develop();
            }
        }
    }
}
