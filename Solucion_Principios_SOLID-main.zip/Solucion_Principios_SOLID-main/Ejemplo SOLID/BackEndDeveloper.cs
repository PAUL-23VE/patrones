﻿namespace Ejemplo_SOLID
{
    /// <summary>
    /// BackEndDeveloper implementa la interfaz IDeveloper
    /// </summary>
    public class BackEndDeveloper : IDeveloper
    {
        void IDeveloper.Develop()
        {
            Console.WriteLine("Desarrollando el BackEnd en C#");
        }
    }
}
