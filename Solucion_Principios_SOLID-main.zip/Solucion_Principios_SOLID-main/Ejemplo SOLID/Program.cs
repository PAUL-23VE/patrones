﻿namespace Ejemplo_SOLID
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Principio de inversion de dependencia");
            List<IDeveloper> developers = new List<IDeveloper>
            {
                new BackEndDeveloper(), new FrontEndDeveloper(), new MobileDevelop()
            };  

            Project project = new Project(developers);
            project.Build();
        }

    }
}
