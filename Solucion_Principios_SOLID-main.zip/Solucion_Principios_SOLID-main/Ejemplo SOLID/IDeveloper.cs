﻿namespace Ejemplo_SOLID
{
    
    public interface IDeveloper
    {
        /// <summary>
        /// Se crea una abstraccion para evitar las dependencias directas.
        /// </summary>
        
        void Develop();


        /*  -static
         *  -virtual
         *  -struct
         *  -record
         *  -Enums
         * public enum Meses{
         * Enero,
             Febrero,
             Marzo,
             Abril,
             Mayo,
             Junio,
             Julio
            }
         * 
         * clases parciales
         * public partial class test
         {
             public int Add(int x, int y)
             {
                 return x + y;
             }
         }

         public partial class test
         {
             public int Substract(int x, int y)
             {
                 return x - y;
             }
         }*/
    }
}
