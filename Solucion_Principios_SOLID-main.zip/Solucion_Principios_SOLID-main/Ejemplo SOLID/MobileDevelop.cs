﻿namespace Ejemplo_SOLID
{
    /// <summary>
    /// Nueva implementacion
    ///
    /// </summary>
    internal class MobileDevelop : IDeveloper
    {
        void IDeveloper.Develop()
        {
            Console.WriteLine("Desarrollando aplicaciones moviles en Flutter");
        }
    }
}
