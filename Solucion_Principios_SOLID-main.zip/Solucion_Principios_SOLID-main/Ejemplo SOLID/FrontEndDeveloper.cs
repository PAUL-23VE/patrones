﻿namespace Ejemplo_SOLID
{
    /// <summary>
    /// FrontEndDeveloper implementa la interfaz IDeveloper
    /// </summary>
    internal class FrontEndDeveloper : IDeveloper
    {
        void IDeveloper.Develop()
        {
            Console.WriteLine("Desarrollando el FrontEnd en React");
        }
    }
}
